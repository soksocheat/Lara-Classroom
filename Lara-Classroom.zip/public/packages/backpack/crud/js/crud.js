/*
*
* Backpack Crud
*
*/

jQuery(function($){

    'use strict';
});
